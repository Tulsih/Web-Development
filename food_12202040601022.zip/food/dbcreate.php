<?php
$servername = "localhost";
$username = "root";
$password = "";
$db_name="porosh";

// $servername = "sql212.infinityfree.com";
// $username = "if0_37707586";
// $password = "28Tulsi123";
// $db_name = "if0_37707586_porosh";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $db_name);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
else
{
    echo "Connection Successful";
}
//Create database
$sql = "CREATE DATABASE porosh";
if (mysqli_query($conn, $sql)) {
    echo "Database created successfully";
} else {
    echo "Error creating database: " . mysqli_error($conn);
}

mysqli_close($conn);
?>